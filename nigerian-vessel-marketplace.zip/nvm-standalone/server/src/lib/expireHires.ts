import { and, eq, inArray, lte } from "drizzle-orm";
import { db, charterPartiesTable, vesselsTable } from "../db";

export async function expireHires(): Promise<void> {
  const now = new Date();
  const active = await db
    .select({ id: charterPartiesTable.id, vesselId: charterPartiesTable.vesselId, hireEnd: charterPartiesTable.hireEnd })
    .from(charterPartiesTable)
    .where(and(eq(charterPartiesTable.status, "active"), lte(charterPartiesTable.hireEnd, now)));

  if (active.length === 0) return;

  const expiredIds = active.map(cp => cp.id);
  const vesselIds = [...new Set(active.map(cp => cp.vesselId))];

  await db.update(charterPartiesTable)
    .set({ status: "terminated", updatedAt: now })
    .where(and(inArray(charterPartiesTable.id, expiredIds), eq(charterPartiesTable.status, "active")));

  await db.update(vesselsTable)
    .set({ status: "available", updatedAt: now })
    .where(and(inArray(vesselsTable.id, vesselIds), eq(vesselsTable.status, "on_hire")));
}
