/**
 * Run this once after creating your Replit PostgreSQL database:
 *   npx ts-node src/migrate.ts
 *
 * It creates all tables if they don't exist.
 */
import "dotenv/config";
import { Pool } from "pg";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const SQL = `
CREATE TABLE IF NOT EXISTS vessel_users (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL,
  email       TEXT NOT NULL UNIQUE,
  password    TEXT NOT NULL,
  role        TEXT NOT NULL DEFAULT 'client',
  company     TEXT,
  phone       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vessels (
  id                      SERIAL PRIMARY KEY,
  owner_id                INTEGER NOT NULL REFERENCES vessel_users(id),
  name                    TEXT NOT NULL,
  imo_number              TEXT,
  vessel_type             TEXT NOT NULL,
  flag                    TEXT,
  dwt                     NUMERIC,
  grt                     NUMERIC,
  year_built              INTEGER,
  loa                     NUMERIC,
  beam                    NUMERIC,
  draft                   NUMERIC,
  classification_society  TEXT,
  trading_area            TEXT,
  description             TEXT,
  status                  TEXT NOT NULL DEFAULT 'available',
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vessel_contacts (
  id            SERIAL PRIMARY KEY,
  vessel_id     INTEGER NOT NULL REFERENCES vessels(id) ON DELETE CASCADE,
  contact_name  TEXT NOT NULL,
  phone         TEXT,
  email         TEXT,
  address       TEXT
);

CREATE TABLE IF NOT EXISTS charter_parties (
  id                    SERIAL PRIMARY KEY,
  vessel_id             INTEGER NOT NULL REFERENCES vessels(id),
  charterer_id          INTEGER NOT NULL REFERENCES vessel_users(id),
  owner_id              INTEGER NOT NULL REFERENCES vessel_users(id),
  rate                  NUMERIC,
  rate_currency         TEXT DEFAULT 'USD',
  rate_basis            TEXT,
  laycan_earliest       TIMESTAMPTZ,
  laycan_latest         TIMESTAMPTZ,
  duration_days         INTEGER,
  cargo_purpose         TEXT,
  terms                 TEXT,
  status                TEXT NOT NULL DEFAULT 'enquiry',
  owner_confirmed_at    TIMESTAMPTZ,
  charterer_confirmed_at TIMESTAMPTZ,
  hire_start            TIMESTAMPTZ,
  hire_end              TIMESTAMPTZ,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vessel_notifications (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES vessel_users(id),
  type        TEXT NOT NULL,
  title       TEXT NOT NULL,
  message     TEXT NOT NULL,
  related_id  INTEGER,
  read        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS vessel_photos (
  id          SERIAL PRIMARY KEY,
  vessel_id   INTEGER NOT NULL REFERENCES vessels(id) ON DELETE CASCADE,
  object_path TEXT NOT NULL,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
`;

pool.query(SQL)
  .then(() => { console.log("All tables created (or already exist)."); process.exit(0); })
  .catch(err => { console.error("Migration failed:", err); process.exit(1); });
