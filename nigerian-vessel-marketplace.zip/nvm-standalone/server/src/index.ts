import "dotenv/config";
import express from "express";
import cors from "cors";
import router from "./routes";
import { expireHires } from "./lib/expireHires";

const app = express();
const PORT = process.env.PORT ?? 3001;

app.use(cors());
app.use(express.json({ limit: "2mb" }));

app.get("/api/healthz", (_req, res) => res.json({ ok: true }));

app.use("/api", router);

app.listen(PORT, () => {
  console.log(`NVM API server running on port ${PORT}`);
  // Expire overdue hires every 5 minutes
  setInterval(() => expireHires().catch(console.error), 5 * 60 * 1000);
});
