# Nigerian Vessel Marketplace

A two-part project: an Express API server (`server/`) and an Expo React Native mobile app (`mobile/`).

---

## Quick start on a new Replit

### 1. Create and configure the project

1. Create a new **Node.js** Repl on Replit
2. Upload and extract this zip into the Repl
3. In **Secrets** (padlock icon), add:
   - `DATABASE_URL` — your Replit PostgreSQL connection string (add the Postgres integration from the DB tab)
   - `JWT_SECRET` — any long random string (e.g. 64 hex characters)
   - `DEFAULT_OBJECT_STORAGE_BUCKET_ID` — your Replit Object Storage bucket ID (for photo uploads)
   - `PRIVATE_OBJECT_DIR` — `vessel-photos`
   - `PUBLIC_OBJECT_SEARCH_PATHS` — `vessel-photos`

### 2. Create the database tables

In the Replit Shell:

```bash
cd server
npm install
npm run migrate
```

This creates all 6 tables (`vessel_users`, `vessels`, `vessel_contacts`, `charter_parties`, `vessel_notifications`, `vessel_photos`).

### 3. Configure the mobile app domain

Once your Repl is published and you know its domain (e.g. `abc123.replit.app`), update `mobile/app.json`:

```json
"plugins": [
  ["expo-router", { "origin": "https://abc123.replit.app/" }]
]
```

Also add a **Secret** in the mobile context:
- `EXPO_PUBLIC_DOMAIN` — `abc123.replit.app`

### 4. Run the server

In your `.replit` file (or Workflow), run:

```
cd server && npm run dev
```

The API server starts on the port Replit assigns via `$PORT` (defaults to 3001 locally).

### 5. Run the mobile/web app

In a second Shell tab or Workflow:

```bash
cd mobile
npm install
npm run web
```

---

## Project structure

```
├── server/
│   ├── src/
│   │   ├── index.ts        — Express entry point
│   │   ├── db.ts           — Drizzle + PostgreSQL setup
│   │   ├── schema.ts       — All 6 database table definitions
│   │   ├── routes.ts       — All API routes
│   │   ├── migrate.ts      — One-shot SQL migration script
│   │   ├── middleware/
│   │   │   └── auth.ts     — JWT auth middleware
│   │   └── lib/
│   │       └── expireHires.ts — Auto-expire finished charters
│   ├── package.json
│   └── tsconfig.json
│
├── mobile/
│   ├── app/                — Expo Router screens
│   ├── components/         — Shared UI components
│   ├── context/            — AuthContext
│   ├── hooks/              — useColors, useUnreadCount
│   ├── lib/                — api.ts, types.ts, vesselValidation.ts
│   ├── constants/          — colors.ts
│   ├── app.json
│   └── package.json
│
├── .env.example
└── README.md
```

---

## API routes

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | /api/vessels/auth/register | — | Register user |
| POST | /api/vessels/auth/login | — | Login |
| GET | /api/vessels | optional | List vessels |
| GET | /api/vessels/:id | optional | Get vessel detail |
| POST | /api/vessels | owner/admin | Create vessel |
| PUT | /api/vessels/:id | owner/admin | Edit vessel |
| PATCH | /api/vessels/:id/status | owner/admin | Set status |
| GET | /api/vessels/:id/photos | — | List photos |
| POST | /api/vessels/:id/photos | owner/admin | Add photo |
| DELETE | /api/vessels/:id/photos/:photoId | owner/admin | Delete photo |
| POST | /api/vessels/:id/charter | client/broker | Submit enquiry |
| GET | /api/charter-parties | auth | My charters |
| PUT | /api/charter-parties/:id | parties | Update terms |
| POST | /api/charter-parties/:id/confirm | parties | Confirm |
| POST | /api/charter-parties/:id/decline | parties | Decline |
| POST | /api/charter-parties/:id/terminate | owner/admin | Terminate |
| GET | /api/vessel-notifications | auth | My notifications |
| PATCH | /api/vessel-notifications/:id/read | auth | Mark read |
| POST | /api/vessel-notifications/read-all | auth | Mark all read |
| GET | /api/vessel-admin/users | admin | List users |
| PATCH | /api/vessel-admin/users/:id/role | admin | Change role |

---

## Roles

- **client** — can browse vessels and submit charter enquiries
- **broker** — same as client (broker-facing flows)
- **owner** — can list/manage their own vessels, confirm/terminate charters
- **admin** — full access, can manage all users and vessels
